package org.example.pr4.geometry;

// Comparable<GeometricObject> уже реализован в GeometricObject и наследуется через Circle.
public class ComparableCircle extends Circle {
    public ComparableCircle() {
    }

    public ComparableCircle(double radius) {
        super(radius);
    }

    @Override
    public int compareTo(GeometricObject other) {
        return Double.compare(getArea(), other.getArea());
    }
}
